// Oláh Tamás-Lajos
// otim1750
// 523 / 2

public interface MainDish {
    public String toString();
}
