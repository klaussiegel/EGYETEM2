// Oláh Tamás-Lajos
// otim1750
// 523 / 2

public class KungPaoChicken implements MainDish {
    @Override
    public String toString() {
        return "Kung Pao Chicken";
    }
}
