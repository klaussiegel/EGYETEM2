// Oláh Tamás-Lajos
// otim1750
// 523 / 2

package core;

public interface Vehicle {
    public String toString();
    public void numberOfWheels();
}
