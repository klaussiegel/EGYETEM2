// Oláh Tamás-Lajos
// otim1750
// 523 / 2

public interface Soup {
    public void associateMainDish(MainDish x);
    public String toString();
}
