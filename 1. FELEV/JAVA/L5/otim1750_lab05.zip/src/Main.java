// Oláh Tamás-Lajos
// otim1750
// 523 / 2

public class Main {
    public static void main(String args[]) {
        new NewColorfulFrame();
        new NewTextFrame();
        new NewFoodFrame();
    }
}
