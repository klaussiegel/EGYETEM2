// Oláh Tamás-Lajos
// otim1750
// 523 / 2

public class ChickpeaCurry implements MainDish {
    @Override
    public String toString() {
        return "Chickpea Curry";
    }
}
