// Oláh Tamás-Lajos
// otim1750
// 523 / 2

public interface Chef {
    public Soup prepareSoup();
    public MainDish prepareMainDish();
}
