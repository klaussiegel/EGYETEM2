// Oláh Tamás-Lajos
// otim1750
// 523 / 2

package collection;

import core.Vehicle;

public interface VehicleIterator {
    public boolean hasMoreElements();
    public Vehicle nextElement();
}
